package com.cg.employeemanagement.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.Login;
import com.cg.employeemanagement.entity.LoginDatabase;

public class LoginDaoImpl implements LoginDao{

	@Override
	public boolean validate(String userName, String pwd, int userRole) {
		// function should check username and pwd from static loginDB present.
		 LoginDatabase logindb=new LoginDatabase();
		List<Login> list= logindb.getLoginDetails();
		String userType;
		if(userRole==1)
		{
			userType="admin";
		}
		else if(userRole==2)
			userType="manager";
		else
			userType="employee";
			
		for(Login l1:list)
		{
			
			if(l1.getUserName().equals(userName)
					&& l1.getPassword().equals(pwd)
					&& l1.getLoginType().equals(userType))
			{
				return true;
			}
		}
		return false;
	}

}
