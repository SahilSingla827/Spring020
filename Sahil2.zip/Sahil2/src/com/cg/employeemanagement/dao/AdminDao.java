package com.cg.employeemanagement.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;



public interface AdminDao {
	public boolean addEmployee(Employee emp);
	public boolean deleteEmployeeById(int empId);
	public boolean modifyEmployeeName(int empId,String empName);
	public boolean modifyEmployeeSalary(int empId,float empSal);
	public boolean modifyEmployeeDepartmentId(int empId,int deptId);
	public boolean modifyEmployeeDOB(int empId,LocalDate dob);
	public boolean modifyEmployeeContactNumber(int empId,Long empContactNumber);
	public boolean modifyEmployeeManagerId(int empId,int empManagerId);
	public Employee searchEmployeeById(int empId);
	public List<Employee> searchEmployessByName(String name);
	public List<Employee> displayEmployees();
	public boolean changeAccountPassword(String newPassword,String userName);
	public boolean checkOldPassword(String oldPassword,String userName);
}
