package com.cg.employeemanagement.pl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.employeemanagement.dao.EmployeeDao;
import com.cg.employeemanagement.dao.EmployeeDaoImpl;
import com.cg.employeemanagement.dao.LoginDao;
import com.cg.employeemanagement.dao.LoginDaoImpl;
import com.cg.employeemanagement.dto.Employee;
import com.cg.employeemanagement.dto.Leave;
import com.cg.employeemanagement.entity.LoginDatabase;
import com.cg.employeemanagement.entity.ReviewedLeavesStaticDB;
import com.cg.employeemanagement.exception.EmpException;
import com.cg.employeemanagement.services.AdminService;
import com.cg.employeemanagement.services.AdminServiceImpl;
import com.cg.employeemanagement.services.EmpService;
import com.cg.employeemanagement.services.EmpServiceImpl;
import com.cg.employeemanagement.services.LoginService;
import com.cg.employeemanagement.services.LoginServiceImpl;
import com.cg.employeemanagement.services.ManagerService;
import com.cg.employeemanagement.services.ManagerServiceImpl;

public class EmployeeManagementDemo {

	public static void main(String[] args) {
		int flag = 0;
		int flag1 = 0;
		String yearPattern = "[0-9]{4}";
		String phonePattern = "[^0][0-9]{9}";
		String namePattern = "[A-Z]{1,1}[a-z]{2,25}";
		String passwordPattern = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{6,12})";
		while (true) {
			System.out.println("Login types:\n" + "\tEnter 1 for : Admin \n " + "\tEnter 2 for : Manager\n "
					+ "\tEnter 3 for : Employee");
			int loginChoice;
			String choice = null;
			LoginService loginService = new LoginServiceImpl();
			Scanner scanner = new Scanner(System.in);
			loginChoice = scanner.nextInt();
			String userName;
			String password;
			boolean valid;
			System.out.println("Enter your User Name:");
			userName = scanner.next();
			System.out.println("Enter your password:");
			password = scanner.next();
			valid = loginService.validate(userName, password, loginChoice);
			if (valid && loginChoice == 1) {
				boolean operation = true;
				while (operation) {
					System.out.println("Admin:\n" + "\t1.Add Employee\n" + "\t2.Delete Employee\n"
							+ "\t3.Modify employee By Id\n" + "\t4.Search employee by Id\n"
							+ "\t5.Search employee by name\n" + "\t6.display all the employees\n" + "\t7.Change Password\n" + "\t8.to exit\n");

					choice = scanner.next();
					scanner.nextLine();
					AdminService adminService = new AdminServiceImpl();

					switch (choice) {
					case "1":
						float empSalary =0f;
						Employee emp;
						System.out.println("Enter Employee Name:");
						String empName = scanner.nextLine();
						
						while (flag != 1) {
							
							if (adminService.isValidName(empName, namePattern))
								flag = 1;
							else {
								System.out.println(
										"Name must start with a capital letter And must have atleast 3 characters");
								System.out.println("Enter Name Again");
								empName = scanner.nextLine();
							}
						}
						flag = 0;

						/*System.out.println("Enter Employee Salary");*/
						
						try
						{
						System.out.println("Enter Employee Salary");
						empSalary = scanner.nextFloat();
						}
						catch(InputMismatchException ime)
						{
							
						}
						
						System.out.println("Enter Employee Department Id");
						int empDeptId = scanner.nextInt();
						System.out.println("Enter employee date of birth in the format yyyy mm dd");
						LocalDate empDOB = null;
						while (flag != 1) {
							int year = 0;
							int month = 0;
							int dayOfMonth = 0;
							System.out.println("Enter year");
							while (flag1 != 1) {
								year = scanner.nextInt();
								if (adminService.isValidYear(String.valueOf(year), yearPattern)) {
									flag1 = 1;
								} else {
									System.out.println("year must be in yyyy format");
									System.out.println("Enter year in yyyy format");
								}

							}
							flag1 = 0;
							System.out.println("Enter month");

							while (flag1 != 1) {
								month = scanner.nextInt();
								if (adminService.isValidMonth(month)) {
									flag1 = 1;
								} else {
									System.out.println("Month can't be greater than  12 or less than 1");
									System.out.println("Enter month again");
								}

							}
							flag1 = 0;

							System.out.println("Enter date");
							while (flag1 != 1) {
								dayOfMonth = scanner.nextInt();
								if (adminService.isValidDay(dayOfMonth, month, year)) {
									flag1 = 1;
								} else {
									System.out.println("In proper day");
									System.out.println("Enter day again");
								}

							}
							empDOB = LocalDate.of(year, month, dayOfMonth);
							if (adminService.isValidDate(empDOB))
								flag = 1;
							else {
								System.out.println("Date of birth cannot be after the present date\n");
								System.out.println("Enter Date of birth again\n");
							}
						}
						flag = 0;
						System.out.println("Enter Employee Contact Number");
						Long empContactNumber = 0L;
						while (flag != 1) {
							empContactNumber = scanner.nextLong();
							if (adminService.isValidPhone(String.valueOf(empContactNumber), phonePattern))
								flag = 1;
							else {
								System.out.println("Contact number must have 10 digits and does not start with 0");
								System.out.println("Enter Contact number Again");
							}
						}
						flag = 0;

						System.out.println("Enter Employee Manager Id");
						int empManagerId = scanner.nextInt();
						emp = new Employee(empName, empSalary, empDeptId, empDOB, empContactNumber, empManagerId, 22);
						boolean status = adminService.addEmployee(emp);
						if (status) {
							System.out.println("Employee is added successfully");
						} else {
							throw new EmpException("error in adding the new employee to the database");
						}
						break;

					// Employee emp;
					// System.out.println("Enter Employee Name:");
					// String empName=scanner.nextLine();
					//
					// System.out.println("Enter Employee Salary");
					// float empSalary=scanner.nextFloat();
					// System.out.println("Enter Employee Department Id");
					// int empDeptId=scanner.nextInt();
					// System.out.println("Enter employee date of birth in the
					// format yyyy mm dd");
					// int year=scanner.nextInt();
					// int month=scanner.nextInt();
					// int dayOfMonth=scanner.nextInt();
					// LocalDate empDOB=LocalDate.of(year, month, dayOfMonth);
					// System.out.println("Enter Employee Contact Number");
					// Long empContactNumber=scanner.nextLong();
					// System.out.println("Enter Employee Manager Id");
					// int empManagerId=scanner.nextInt();
					// emp=new
					// Employee(empName,empSalary,empDeptId,empDOB,empContactNumber,empManagerId,22);
					// boolean status=adminService.addEmployee(emp);
					// if(status)
					// {
					// System.out.println("Employee is added successfully");
					// }
					// else
					// {
					// throw new EmpException("error in adding the new employee
					// to the database");
					// }
					// break;

					case "2":
						System.out.println("Enter Employee Id for deletion");
						int empDeleteId = scanner.nextInt();
						boolean deletionStatus = adminService.deleteEmployeeById(empDeleteId);
						if (deletionStatus) {
							System.out.println("Employee is deleted Sucessfully");
						} else {
							throw new EmpException("error in deleting the employee from database");
						}
						break;
					case "3":
						// Im writing code for only name modification as of now
						System.out.println("Enter Employee Id for Modification");
						int empToBeModifiedId = scanner.nextInt();
						System.out.println("\nEnter 1: to update name\n" + "Enter 2: to update Salary\n"
								+ "Enter 3: to update Department id\n" + "Enter 4: to update Date of Birth\n"
								+ "Enter 5: to update Contact Number\n" + "Enter 6: to update Manager Id\n");
						int modifyChoice = scanner.nextInt();
						boolean bool;
						switch (modifyChoice) {
						case 1:
							flag = 0;
							System.out.println("Enter the new Name");
							String newName = scanner.nextLine();
							// scanner.nextLine();
							while (flag != 1) {
								newName = scanner.nextLine();
								if (adminService.isValidName(newName, namePattern))
									flag = 1;
								else {
									System.out.println(
											"Name must start with a capital letter And must have atleast 3 characters");
									System.out.println("Enter Name Again");
								}
							}
							flag = 0;
							bool = adminService.modifyEmployeeName(empToBeModifiedId, newName);
							break;
						case 2:
							System.out.println("Enter the new Salary");
							float newSal = scanner.nextFloat();
							bool = adminService.modifyEmployeeSalary(empToBeModifiedId, newSal);
							break;
						case 3:
							System.out.println("Enter the new Department Id");
							int newdeptId = scanner.nextInt();
							bool = adminService.modifyEmployeeDepartmentId(empToBeModifiedId, newdeptId);
							break;
						case 4:
							flag1 = 0;
							flag = 0;
							System.out.println("Enter the correct Date Of Birth");
							LocalDate newDOB = null;
							int correctYear = 0;
							int correctMonth = 0;
							int correctDayOfMonth = 0;
							while (flag != 1) {

								System.out.println("Enter year");
								while (flag1 != 1) {
									correctYear = scanner.nextInt();
									if (adminService.isValidYear(String.valueOf(correctYear), yearPattern)) {
										flag1 = 1;
									} else {
										System.out.println("year must be in yyyy format");
										System.out.println("Enter year in yyyy format");
									}

								}
								flag1 = 0;
								System.out.println("Enter month");

								while (flag1 != 1) {
									correctMonth = scanner.nextInt();
									if (adminService.isValidMonth(correctMonth)) {
										flag1 = 1;
									} else {
										System.out.println("Month can't be greater than  12 or less than 1");
										System.out.println("Enter month again");
									}

								}
								flag1 = 0;

								System.out.println("Enter date");
								while (flag1 != 1) {
									correctDayOfMonth = scanner.nextInt();
									if (adminService.isValidDay(correctDayOfMonth, correctMonth, correctYear)) {
										flag1 = 1;
									} else {
										System.out.println("In proper day");
										System.out.println("Enter day again");
									}

								}
								flag1 = 0;
								newDOB = LocalDate.of(correctYear, correctMonth, correctDayOfMonth);
								if (adminService.isValidDate(newDOB))
									flag = 1;
								else {
									System.out.println("Date of birth cannot be after the present date");
									System.out.println("Emter Date of birth again");
								}
							}
							flag = 0;

							bool = adminService.modifyEmployeeDOB(empToBeModifiedId, newDOB);
							break;
						case 5:
							System.out.println("Enter the new Contact Number");
							Long newContactNumber = 0L;
							while (flag != 1) {
								newContactNumber = scanner.nextLong();
								if (adminService.isValidPhone(String.valueOf(newContactNumber), phonePattern))
									flag = 1;
								else {
									System.out.println("Contact number must have 10 digits and does not start with 0");
									System.out.println("Enter Contact number Again");
								}
							}
							flag = 0;

							bool = adminService.modifyEmployeeContactNumber(empToBeModifiedId, newContactNumber);
							break;
						case 6:
							System.out.println("Enter the new Manager's Id");
							int newManagerId = scanner.nextInt();
							bool = adminService.modifyEmployeeManagerId(empToBeModifiedId, newManagerId);
							break;

						// case 1:
						// System.out.println("Enter the new Name");
						// String newName=scanner.nextLine();
						// bool =
						// adminService.modifyEmployeeName(empToBeModifiedId,
						// newName);
						// break;
						// case 2:
						// System.out.println("Enter the new Salary");
						// float newSal=scanner.nextFloat();
						// bool =
						// adminService.modifyEmployeeSalary(empToBeModifiedId,
						// newSal);
						// break;
						// case 3:
						// System.out.println("Enter the new Department Id");
						// int newdeptId=scanner.nextInt();
						// bool =
						// adminService.modifyEmployeeDepartmentId(empToBeModifiedId,
						// newdeptId);
						// break;
						// case 4:
						// System.out.println("Enter the correct Date Of
						// Birth");
						// int correctYear=scanner.nextInt();
						// int correctMonth=scanner.nextInt();
						// int correctDayOfMonth=scanner.nextInt();
						// LocalDate newDOB=LocalDate.of(correctYear,
						// correctMonth, correctDayOfMonth);
						// bool =
						// adminService.modifyEmployeeDOB(empToBeModifiedId,
						// newDOB);
						// break;
						// case 5:
						// System.out.println("Enter the new Contact Number");
						// Long newContactNumber=scanner.nextLong();
						// bool =
						// adminService.modifyEmployeeContactNumber(empToBeModifiedId,
						// newContactNumber);
						// break;
						// case 6:
						// System.out.println("Enter the new Manager's Id");
						// int newManagerId=scanner.nextInt();
						// bool =
						// adminService.modifyEmployeeManagerId(empToBeModifiedId,
						// newManagerId);
						// break;
						}
						break;

					case "4":
						Employee searchedEmp;
						String empSearchId=null;;
						System.out.println("Enter employee id to be searched");
						empSearchId = scanner.next();
						while(empSearchId.length()>6)
						{
							System.out.println("Employee Id must not be more than 6 characters\nEnter again");
							empSearchId = scanner.next();
						}
						searchedEmp = adminService.searchEmployeeById(empSearchId);
						while(searchedEmp!=null &&searchedEmp.getUserId()==0 )
						{
						System.out.println("Employee Id must be a numeric value");
						System.out.println("Enter employee id to be searched again");
						empSearchId = scanner.next();
						searchedEmp = adminService.searchEmployeeById(empSearchId);
						}
						if(searchedEmp!=null)
						{
						System.out.println("The employee details are: \n");
						System.out.printf("%-25s:%-20s\n","Employee ID",searchedEmp.getUserId());
						System.out.printf("%-25s:%-20s\n","Name",searchedEmp.getUserName());
						System.out.printf("%-25s:%-20s\n","Salary",searchedEmp.getSalary());
						System.out.printf("%-25s:%-20s\n","Department Id",searchedEmp.getDepartmentId());
						System.out.printf("%-25s:%-20s\n","Date of Birth",searchedEmp.getDateOfBirth());
						System.out.printf("%-25s:%-20s\n","Contact Number",searchedEmp.getContactNumber());
						System.out.printf("%-25s:%-20s\n","Manager Id",searchedEmp.getManagerId());
						System.out.printf("%-25s:%-20s\n","Number of leaves left",searchedEmp.getNoOfLeaves());
						System.out.println();
						}
						else
						{
							System.out.println("Employee with id "+empSearchId+" not found \n");
						}
						break;

					case "5":
						System.out.println("Enter Employee name for searching");
						String empSearchByName = scanner.next();
						List<Employee> employeeList = adminService.searchEmployessByName(empSearchByName);
						for (Employee resultEmp : employeeList) {
							System.out.println(resultEmp);
						}
						break;
					case "6":
						List<Employee> empTotalList = adminService.displayEmployees();
						for (Employee totalEmp : empTotalList) {
							System.out.println(totalEmp);
						}
						break;
					case "7":
						System.out.println("Enter old password");
						String oldPassword = scanner.next();
						boolean checkOldPassword = adminService.checkOldPassword(oldPassword, userName);
						if(checkOldPassword)
						{
						System.out.println("Enter new password");
						
						flag=0;
						String newPassword=null;
						while(flag!=1)
						{
							newPassword = scanner.next();
							if(adminService.validatePassword(newPassword,passwordPattern))
							{
								flag=1;
							}
							else
							{
								System.out.println("Be between 6 and 12 characters "
										+ "long Contain at least one digit."
										+ "Contain at least one lower case character."
										+ "Contain at least one upper case character."
										+ "Contain at least on special character from [ @ # $ % ! . ].");
								System.out.println("Enter New Password again");
							}
						
						}
						flag=0;
						boolean pwdChangeStatus = adminService.changeAccountPassword(newPassword,
								userName);
						if (pwdChangeStatus) {
							System.out.println("changed successfully\n");
						}
						else
						{
							System.out.println("Enter correct old password");
						}
						}
						else
						{
							System.out.println("Enter correct old password");
						}
						break;

					case "8":
						operation = false;
						break;

					default:
						System.out.println("Exit");
					}
				}
			}

			else if (valid && loginChoice == 2) {
				boolean operation = true;
				while (operation) {

					System.out.println(
							"Manager\n" 
							+ "\t1.Search By employee Id\n" 
							+ "\t2.Search employee by name\n"
							+ "\t3.Display own details\n" 
							+ "\t4.Display all subordinates\n"
							+ "\t5.Show leaves applied by employees\n" 
							+ "\t6.Accept leave\n" 
							+ "\t7.Reject leave\n"
							+ "\t8.To change Account Password\n" 
							+"\t9. To exit\n");

					choice = scanner.next();

					ManagerService managerService = new ManagerServiceImpl();
					switch (choice) {
					case "1":
						Employee searchedEmp;
						String empSearchId;
						System.out.println("Enter employee id to be searched");
						empSearchId = scanner.next();
						while(empSearchId.length()>6)
						{
							System.out.println("Employee Id must not be more than 6 characters\nEnter again");
							empSearchId = scanner.next();
						}
						searchedEmp = managerService.searchEmployeeById(empSearchId);
						while(searchedEmp!=null &&searchedEmp.getUserId()==0 )
						{
						System.out.println("Employee Id must be a numeric value");
						System.out.println("Enter employee id to be searched again");
						empSearchId = scanner.next();
						searchedEmp = managerService.searchEmployeeById(empSearchId);
						}
						if(searchedEmp!=null)
						{
						System.out.println("The employee details are: \n");
						System.out.printf("%-25s:%-20s\n","Employee ID",searchedEmp.getUserId());
						System.out.printf("%-25s:%-20s\n","Name",searchedEmp.getUserName());
						System.out.printf("%-25s:%-20s\n","Salary",searchedEmp.getSalary());
						System.out.printf("%-25s:%-20s\n","Department Id",searchedEmp.getDepartmentId());
						System.out.printf("%-25s:%-20s\n","Date of Birth",searchedEmp.getDateOfBirth());
						System.out.printf("%-25s:%-20s\n","Contact Number",searchedEmp.getContactNumber());
						System.out.printf("%-25s:%-20s\n","Manager Id",searchedEmp.getManagerId());
						System.out.printf("%-25s:%-20s\n","Number of leaves left",searchedEmp.getNoOfLeaves());
						System.out.println();
						}
						else
						{
							System.out.println("Employee with id "+empSearchId+" not found \n");
						}
						break;

					case "2":
						
						System.out.println("Enter Employee name to be searched");
						String empName = scanner.next();
						List<Employee> empTotalList = managerService.searchEmployeeByName(empName);
						if(empTotalList.size()>0)
						{
						for (Employee emp : empTotalList) {
							System.out.printf("%-25s:%-20s\n","Employee ID",emp.getUserId());
							System.out.printf("%-25s:%-20s\n","Name",emp.getUserName());
							System.out.printf("%-25s:%-20s\n","Salary",emp.getSalary());
							System.out.printf("%-25s:%-20s\n","Department Id",emp.getDepartmentId());
							System.out.printf("%-25s:%-20s\n","Date of Birth",emp.getDateOfBirth());
							System.out.printf("%-25s:%-20s\n","Contact Number",emp.getContactNumber());
							System.out.printf("%-25s:%-20s\n","Manager Id",emp.getManagerId());
							System.out.printf("%-25s:%-20s\n","Number of leaves left",emp.getNoOfLeaves());
							System.out.println();
							break;
						}
						}
						else
						{
							System.out.println("Employee with name"+empName+" not found \n");
						}
						break;

					case "3":
						
						Employee empOwnDetails = managerService.displayOwnDetails(userName);
						
						System.out.printf("%-25s:%-20s\n","Employee ID",empOwnDetails.getUserId());
						System.out.printf("%-25s:%-20s\n","Name",empOwnDetails.getUserName());
						System.out.printf("%-25s:%-20s\n","Salary",empOwnDetails.getSalary());
						System.out.printf("%-25s:%-20s\n","Department Id",empOwnDetails.getDepartmentId());
						System.out.printf("%-25s:%-20s\n","Date of Birth",empOwnDetails.getDateOfBirth());
						System.out.printf("%-25s:%-20s\n","Contact Number",empOwnDetails.getContactNumber());
						System.out.printf("%-25s:%-20s\n","Manager Id",empOwnDetails.getManagerId());
						System.out.printf("%-25s:%-20s\n","Number of leaves left",empOwnDetails.getNoOfLeaves());
						System.out.println();
						break;

					case "4":
						
						List<Employee> subEmpList = managerService.displaySubEmployees(userName);
						if(subEmpList.size()>0)
						{
						for (Employee subordinate : subEmpList) {
							System.out.println("\tEmployee Id : " + subordinate.getUserId() + "\n\tName : "
									+ subordinate.getUserName() + "\n\tSalary : " + subordinate.getSalary()
									+ "\n\tDepartment Id : " + subordinate.getDepartmentId() + "\n\tDate of Birth : "
									+ subordinate.getDateOfBirth() + "\n\tContact Number : "
									+ subordinate.getContactNumber() + "\n\tManager Id : " + subordinate.getManagerId()
									+ "\n\tNumber of leaves left : " + subordinate.getNoOfLeaves());
							System.out.println("\n\n");
						}
						}
						else
						{
							System.out.println("There are no employees under You \n");
						}
						break;

					case "5":
						
						List<Leave> leaveList = managerService.showLeavesApplied(userName);
						if(leaveList.size()>0)
						{
						for (Leave leave : leaveList) {
							
							System.out.printf("%-25s:%-25s\n","Leave Id",leave.getLeaveId());
							System.out.printf("%-25s:%-25s\n","Employee Id",leave.getEmpId());
							System.out.printf("%-25s:%-25s\n","Manager Id",leave.getManagerId());
							System.out.printf("%-25s:%-25s\n","From Date",leave.getFromDate());
							System.out.printf("%-25s:%-25s\n","To Date",leave.getToDate());
							System.out.printf("%-25s:%-25s\n","Appled Date",leave.getAppliedDate());
							System.out.printf("%-25s:%-25s\n","Reason for leave",leave.getReason());
							System.out.printf("%-25s:%-25s\n","Leave Status",leave.getStatus());
//							
//							if (!leave.isLeaveStatus()) {
////								System.out.printf("%-25s:%-25s\n","Leave Status","Pending for approval\n");
////							}
						}
						}
						else
						{
							System.out.println("There are no leaves to be approved\n");
						}
						
						break;

					case "6":
						
						System.out.println("Enter leave id to be accepted");
						int leaveId = scanner.nextInt();
						boolean leaveAcceptStatus = managerService.accept(leaveId);
						if (leaveAcceptStatus) {
							System.out.println("Leave accepted sucessfully\n");
						}
						break;

					case "7":
						
						System.out.println("Enter leave id for rejection");
						int leaveId2 = scanner.nextInt();
						System.out.println("Enter reason for rejection");
						String reason = scanner.next();
						boolean rejectStatus = managerService.reject(leaveId2, reason);
						if (rejectStatus) {
							System.out.println("Sucessfully rejected\n");
						}
						break;
					case "8":
						System.out.println("Enter old password");
						String oldPassword = scanner.next();
						boolean checkOldPassword = managerService.checkOldPassword(oldPassword, userName);
						if(checkOldPassword)
						{
						System.out.println("Enter new password");
						
						flag=0;
						String newPassword=null;
						while(flag!=1)
						{
							newPassword = scanner.next();
							if(managerService.validatePassword(newPassword,passwordPattern))
							{
								flag=1;
							}
							else
							{
								System.out.println("Be between 6 and 12 characters "
										+ "long Contain at least one digit."
										+ "Contain at least one lower case character."
										+ "Contain at least one upper case character."
										+ "Contain at least on special character from [ @ # $ % ! . ].");
								System.out.println("Enter New Password again");
							}
						
						}
						flag=0;
						boolean pwdChangeStatus = managerService.changeAccountPassword(newPassword,
								userName);
						if (pwdChangeStatus) {
							System.out.println("changed successfully\n");
						}
						else
						{
							System.out.println("Enter correct old password");
						}
						}
						else
						{
							System.out.println("Enter correct old password");
						}
						break;

					case "9":
						operation = false;
						break;

					default:
						System.out.println("Enter valid choice\n");
					}
				}

			} else if (valid && loginChoice == 3) {
				boolean operation = true;
				while (operation) {
					System.out.println("Employee\n" 
							+ "\t1.Search Employee By Id\n" 
							+ "\t2.Search Employee By Name\n"
							+ "\t3.Display their own details\n" 
							+ "\t4.change account password\n"
							+ "\t5.apply for leave\n" 
							+ "\t6.Edit leave\n" 
							+ "\t7.view his leave\n"
							+ "\t8.cancel any leave\n" 
							+ "\t9.to logout");
					int leaveId;
					String employeeChoice = scanner.next();
					EmpService employeeService = new EmpServiceImpl();
					ReviewedLeavesStaticDB rlsdb = new ReviewedLeavesStaticDB();
					switch (employeeChoice) {
					case "1":
						Employee searchedEmp;
						String empSearchId=null;;
						System.out.println("Enter employee id to be searched");
						empSearchId = scanner.next();
						while(empSearchId.length()>6)
						{
							System.out.println("Employee Id must not be more than 6 characters\nEnter again");
							empSearchId = scanner.next();
						}
						searchedEmp = employeeService.searchEmployeeById(empSearchId);
						while(searchedEmp!=null &&searchedEmp.getUserId()==0 )
						{
						System.out.println("Employee Id must be a numeric value");
						System.out.println("Enter employee id to be searched again");
						empSearchId = scanner.next();
						searchedEmp = employeeService.searchEmployeeById(empSearchId);
						}
						if(searchedEmp!=null)
						{
						System.out.println("The employee details are: \n");
						System.out.printf("%-25s:%-20s\n","Employee ID",searchedEmp.getUserId());
						System.out.printf("%-25s:%-20s\n","Name",searchedEmp.getUserName());
						System.out.printf("%-25s:%-20s\n","Salary",searchedEmp.getSalary());
						System.out.printf("%-25s:%-20s\n","Department Id",searchedEmp.getDepartmentId());
						System.out.printf("%-25s:%-20s\n","Date of Birth",searchedEmp.getDateOfBirth());
						System.out.printf("%-25s:%-20s\n","Contact Number",searchedEmp.getContactNumber());
						System.out.printf("%-25s:%-20s\n","Manager Id",searchedEmp.getManagerId());
						System.out.printf("%-25s:%-20s\n","Number of leaves left",searchedEmp.getNoOfLeaves());
						System.out.println();
						}
						else
						{
							System.out.println("Employee with id "+empSearchId+" not found \n");
						}
						break;
					case "2":
						System.out.println("Enter Employee name to be searched");
						String empName = scanner.next();
						List<Employee> empTotalList = employeeService.searchEmployeeByName(empName);
						for (Employee result : empTotalList) {
							System.out.println(result);
						}
						break;
					case "3":
						Employee empOwnDetails = employeeService.displayEmpDetails(userName);
						System.out.println(empOwnDetails);
						break;
					case "4":
						System.out.println("Enter old password");
						String oldPassword = scanner.next();
						boolean checkOldPassword = employeeService.checkOldPassword(oldPassword, userName);
						if(checkOldPassword)
						{
						System.out.println("Enter new password");
						
						flag=0;
						String newPassword=null;
						while(flag!=1)
						{
							newPassword = scanner.next();
							if(employeeService.validatePassword(newPassword,passwordPattern))
							{
								flag=1;
							}
							else
							{
								System.out.println("Be between 6 and 12 characters "
										+ "long Contain at least one digit."
										+ "Contain at least one lower case character."
										+ "Contain at least one upper case character."
										+ "Contain at least on special character from [ @ # $ % ! . ].");
								System.out.println("Enter New Password again");
							}
						
						}
						flag=0;
						boolean pwdChangeStatus = employeeService.changeAccountPassword(newPassword,
								userName);
						if (pwdChangeStatus) {
							System.out.println("changed successfully\n");
						}
						else
						{
							System.out.println("Enter correct old password");
						}
						}
						else
						{
							System.out.println("Enter correct old password");
						}
						break;


					case "5":
						
						System.out.println("Enter from date in the format yyyy mm dd");
						LocalDate fDate = null;
						LocalDate tDate = null;
						LocalDate today = null;
						int fromYear = 0;
						int fromMonth = 0;
						int fromDate = 0;
						int toYear = 0;
						int toMonth = 0;
						int toDate = 0;
						flag = 0;
						flag1 = 0;
						while (flag != 1) {
							System.out.println("Enter year");
							while (flag1 != 1) {
								fromYear = scanner.nextInt();
								if (employeeService.isValidYear(String.valueOf(fromYear), yearPattern)) {
									flag1 = 1;
								} else {
									System.out.println("year must be in yyyy format");
									System.out.println("Enter year in yyyy format");
								}

							}
							flag1 = 0;
							System.out.println("Enter month");

							while (flag1 != 1) {
								fromMonth = scanner.nextInt();
								if (employeeService.isValidMonth(fromMonth)) {
									flag1 = 1;
								} else {
									System.out.println("Month can't be greater than  12 or less than 1");
									System.out.println("Enter month again");
								}

							}
							flag1 = 0;

							System.out.println("Enter date");
							while (flag1 != 1) {
								fromDate = scanner.nextInt();
								if (employeeService.isValidDay(fromDate, fromMonth, fromYear)) {
									flag1 = 1;
								} else {
									System.out.println("In proper day");
									System.out.println("Enter day again");
								}

							}

							fDate = LocalDate.of(fromYear, fromMonth, fromDate);
							if (employeeService.validateFromDate(fDate)) {
								flag = 1;
							} else {
								System.out
										.println("From date cannont be before present date or cannot be after 45 days");
								System.out.println("Enter From date again in the format yyyy mm dd");
							}
						}
						flag = 0;
						flag1 = 0;
						System.out.println("Enter to date in format yyyy mm dd");
						while (flag != 1) {
							System.out.println("Enter year");
							while (flag1 != 1) {
								toYear = scanner.nextInt();
								if (employeeService.isValidYear(String.valueOf(toYear), yearPattern)) {
									flag1 = 1;
								} else {
									System.out.println("year must be in yyyy format");
									System.out.println("Enter year in yyyy format");
								}

							}
							flag1 = 0;
							System.out.println("Enter month");

							while (flag1 != 1) {
								toMonth = scanner.nextInt();
								if (employeeService.isValidMonth(toMonth)) {
									flag1 = 1;
								} else {
									System.out.println("Month can't be greater than  12 or less than 1");
									System.out.println("Enter month again");
								}

							}
							flag1 = 0;

							System.out.println("Enter date");
							while (flag1 != 1) {
								toDate = scanner.nextInt();
								if (employeeService.isValidDay(toDate, toMonth, toYear)) {
									flag1 = 1;
								} else {
									System.out.println("In proper day");
									System.out.println("Enter day again");
								}

							}

							tDate = LocalDate.of(toYear, toMonth, toMonth);
							today = LocalDate.now();
							if (employeeService.validateTODate(fDate, tDate)) {
								flag = 1;
							} else {
								System.out.println(
										"To date can't be before From date and To date can't be after 10 from from date");
								System.out.println("Enter to date in format yyyy mm dd");
							}
						}

						System.out.println("Enter reason for leave");
						String reason = scanner.nextLine();
						int empId = employeeService.getIdFromUsername(userName);// write code to get access present
										// employee id from loginDatabase;
						//Also get the manager manager id of employee 
						int mgrId=employeeService.getManagerId(empId);
						Leave leave = new Leave(fDate, tDate, today, false, empId, mgrId, reason);
						boolean leaveStatus = employeeService.addLeave(leave);
						if (leaveStatus) {
							System.out.println("Sucessfully");
						}
						break;
						
					case "6":
						
						int fromYear1 = 0;
						int fromMonth1 = 0;
						int fromDate1 = 0;
						LocalDate fDate1 = null;
						int toYear1 = 0;
						int toMonth1 = 0;
						int toDate1 = 0;
						LocalDate tDate1 = null;
						LocalDate today1 = null;
						System.out.println("Enter leave id to modify leave");
						leaveId = scanner.nextInt();
						System.out.println("Enter from date in the format yyyy mm dd");
						while (flag != 1) {
							System.out.println("Enter year");
							while (flag1 != 1) {
								fromYear1 = scanner.nextInt();
								if (employeeService.isValidYear(String.valueOf(fromYear1), yearPattern)) {
									flag1 = 1;
								} else {
									System.out.println("year must be in yyyy format");
									System.out.println("Enter year in yyyy format");
								}

							}
							flag1 = 0;
							System.out.println("Enter month");

							while (flag1 != 1) {
								fromMonth1 = scanner.nextInt();
								if (employeeService.isValidMonth(fromMonth1)) {
									flag1 = 1;
								} else {
									System.out.println("Month can't be greater than  12 or less than 1");
									System.out.println("Enter month again");
								}

							}
							flag1 = 0;

							System.out.println("Enter date");
							while (flag1 != 1) {
								fromDate1 = scanner.nextInt();
								if (employeeService.isValidDay(fromDate1, fromMonth1, fromYear1)) {
									flag1 = 1;
								} else {
									System.out.println("In proper day");
									System.out.println("Enter day again");
								}

							}

							fDate1 = LocalDate.of(fromYear1, fromMonth1, fromDate1);
							if (employeeService.validateFromDate(fDate1)) {
								flag = 1;
							} else {
								System.out
										.println("From date cannont be before present date or cannot be after 45 days");
								System.out.println("Enter From date again in the format yyyy mm dd");
							}
						}
						flag = 0;
						flag1 = 0;
						System.out.println("Enter to date in format yyyy mm dd");
						while (flag != 1) {
							System.out.println("Enter year");
							while (flag1 != 1) {
								toYear1 = scanner.nextInt();
								if (employeeService.isValidYear(String.valueOf(toYear1), yearPattern)) {
									flag1 = 1;
								} else {
									System.out.println("year must be in yyyy format");
									System.out.println("Enter year in yyyy format");
								}

							}
							flag1 = 0;
							System.out.println("Enter month");

							while (flag1 != 1) {
								toMonth1 = scanner.nextInt();
								if (employeeService.isValidMonth(toMonth1)) {
									flag1 = 1;
								} else {
									System.out.println("Month can't be greater than  12 or less than 1");
									System.out.println("Enter month again");
								}

							}
							flag1 = 0;

							System.out.println("Enter date");
							while (flag1 != 1) {
								toDate1 = scanner.nextInt();
								if (employeeService.isValidDay(toDate1, toMonth1, toYear1)) {
									flag1 = 1;
								} else {
									System.out.println("In proper day");
									System.out.println("Enter day again");
								}

							}

							tDate1 = LocalDate.of(toYear1, toMonth1, toDate1);
							today = LocalDate.now();
							if (employeeService.validateTODate(fDate1, tDate1)) {
								flag = 1;
							} else {
								System.out.println(
										"To date can't be before From date and To date can't be after 10 from from date");
								System.out.println("Enter to date in format yyyy mm dd");
							}
						}
						Leave editedLeave = employeeService.editLeave(leaveId, fDate1, tDate1);
						System.out.println("leave modified to: " + editedLeave);
						break;

					case "7":
						
						List<Leave> leaveList = new ArrayList<Leave>();
						int empid = employeeService.getIdFromUsername(userName);
//						int leave
						leaveList = employeeService.SearchLeave(empid);
						
						System.out.println(leaveList);
						break;

					case "8":
						System.out.println("Enter the leave Id to cancell the leave");
						leaveId = scanner.nextInt();
						boolean cancellApprovalStatus = employeeService.cancelLeave(leaveId);
						if (cancellApprovalStatus) {
							System.out.println("Leave is cancelled successfully");
						}
						break;
					case "9":
						operation = false;
						break;
					default:
						System.out.println("Enter Valid Choice");
					}
				}

			} 
			else {
				System.out.println("Invalid login credentials");
			}
			
		}

	}

}
