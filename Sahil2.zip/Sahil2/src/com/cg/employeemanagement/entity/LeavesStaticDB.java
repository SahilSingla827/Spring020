package com.cg.employeemanagement.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.employeemanagement.dto.Leave;



public class LeavesStaticDB {
	private static List<Leave> leavesList=new ArrayList<Leave>(); 
	
	static {
		
		leavesList.add(new Leave(LocalDate.of(2020, 04, 12),LocalDate.of(2020, 04, 16),
				LocalDate.now(),false,6,5,"planned trip"));
		leavesList.add(new Leave(LocalDate.of(2020, 05, 12),LocalDate.of(2020, 05, 16),
				LocalDate.now(),false,4,5,"for sister's marriage"));
		
	}

	public List<Leave> getLeavesList()
	{
		
		return leavesList;
	}
	
	public boolean add(Leave l)
	{
		leavesList.add(l);
		return true;
	}
	
	public boolean removeLeave(int leaveId)
	{
		
		List<Leave> tempList =new ArrayList<Leave>(leavesList);
		Iterator<Leave> it =tempList.iterator();
		while(it.hasNext())
		{
			Leave l=it.next();
			if(l.getLeaveId()==leaveId)
			{
				leavesList.remove(l);
			}
		}
		
		return true;
	}
}
