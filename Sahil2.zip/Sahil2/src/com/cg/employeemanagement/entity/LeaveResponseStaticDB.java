package com.cg.employeemanagement.entity;

import java.util.ArrayList;
import java.util.List;

import com.cg.employeemanagement.dto.LeaveResponse;

public class LeaveResponseStaticDB {
	private static List<LeaveResponse> leaveResponse = new ArrayList<>();
	
	public LeaveResponseStaticDB() {
		super();
	}

	public boolean add(int empId, int leaveid, String response)
	{
		leaveResponse.add(new LeaveResponse(empId,leaveid, response));
		return true;
	}

}
