package com.cg.employeemanagement.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.employeemanagement.dto.Employee;

public class EmployeeStaticDB {
	private static List<Employee> empList = new ArrayList<Employee>();
	private LoginDatabase loginDB = new LoginDatabase();
	Iterator<Employee> it = empList.iterator();
	static
	{
		empList.add(new Employee("Adarsha Reddy", 15000, 101, LocalDate.of(1998, 12, 28), 753992104l, 2, 22));
		empList.add(new Employee("Naresh Babu", 18000, 102, LocalDate.of(1995, 05, 02), 15236984l, 2, 22));
		empList.add(new Employee("suresh", 15000, 101, LocalDate.of(1989, 01, 26), 45698715l, 3, 22));
		empList.add(new Employee("chintu", 15000, 103, LocalDate.of(1982, 10, 8), 23659810l, 5, 22));
		empList.add(new Employee("Sahil", 15000, 104, LocalDate.of(1985, 03, 16), 189657483l, 5, 22));
		empList.add(new Employee("priya", 15000, 105, LocalDate.of(1990, 01, 3), 369874561l, 5, 22));
	}
	public List<Employee> getEmployeeList() {
		return empList;
	}

	public boolean addData(Employee emp) {
		
		boolean b = empList.add(emp);
		loginDB.addCredentials(emp);
		return b;
	}

	public boolean delete(int id) {
		boolean bool = false;
		while(it.hasNext())
		{
			Employee e=it.next();
			if (e.getUserId() == id) {
				bool = empList.remove(e);
				break;
				
			}
		}
		return bool;
	}

	public void modifyEmployeeName(int empId, String empName) {

		for (Employee e : empList) {
			if (e.getUserId() == empId) {
				e.setUserName(empName);
			}
		}
	}

	public void modifyEmployeeSalary(int empId, float empSal) {
		for (Employee e : empList) {
			if (e.getUserId() == empId) {
				e.setSalary(empSal);
			}
		}
	}

	public void modifyEmployeeDepartmentId(int empId, int deptId) {
		for (Employee e : empList) {
			if (e.getUserId() == empId) {
				e.setDepartmentId(deptId);
			}
		}
	}

	public void modifyEmployeeDOB(int empId, LocalDate dob) {
		for (Employee e : empList) {
			if (e.getUserId() == empId) {
				e.setDateOfBirth(dob);
			}
		}
	}

	public void modifyEmployeeContactNumber(int empId, Long empContactNumber) {
		for (Employee e : empList) {
			if (e.getUserId() == empId) {
				e.setContactNumber(empContactNumber);
			}
		}
	}

	public void modifyEmployeeManagerId(int empId, int empManagerId) {
		for (Employee e : empList) {
			if (e.getUserId() == empId) {
				e.setManagerId(empManagerId);
			}
		}
	}
	public int getManagerId(int empId)
	   {
		for (Employee e : empList) 
		{
			if (e.getUserId()== empId)
			{
				return e.getManagerId();
			}
	   }
		return 0;

	   }
}
