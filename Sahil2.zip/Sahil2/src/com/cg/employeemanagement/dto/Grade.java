package com.cg.employeemanagement.dto;

public class Grade {
	private int gradeId;
	private double minimunSalary;
	private double maximumSalary;
	public int getGradeId() {
		return gradeId;
	}
	public void setGradeId(int gradeId) {
		this.gradeId = gradeId;
	}
	public double getMinimunSalary() {
		return minimunSalary;
	}
	public void setMinimunSalary(double minimunSalary) {
		this.minimunSalary = minimunSalary;
	}
	public double getMaximumSalary() {
		return maximumSalary;
	}
	public void setMaximumSalary(double maximumSalary) {
		this.maximumSalary = maximumSalary;
	}
	
}
